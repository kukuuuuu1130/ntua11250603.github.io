# GitHub 部署指南

## 📋 前置準備

1. 確保您有 GitHub 帳戶
2. 安裝 Git 工具
3. 準備好本地項目檔案

---

## 🚀 部署步驟

### 步驟 1：建立 GitHub 倉庫

1. 登入 [GitHub](https://github.com)
2. 點擊右上角「+」→「New repository」
3. 填寫倉庫信息：
   - **Repository name**：`game-awards-showcase`
   - **Description**：Figma to Web 遊戲展示網站
   - **Public**：選擇公開
   - **Initialize this repository with**：不勾選
4. 點擊「Create repository」

### 步驟 2：配置本地 Git

```bash
# 進入項目目錄
cd /home/ubuntu/game-awards-showcase

# 配置用戶信息（如果還沒配置）
git config user.email "mark171@gmail.com"
git config user.name "鄭依晴"

# 檢查 Git 狀態
git status
```

### 步驟 3：添加遠端倉庫

```bash
# 添加遠端倉庫（將 YOUR_USERNAME 替換為您的 GitHub 用戶名）
git remote add origin https://github.com/YOUR_USERNAME/game-awards-showcase.git

# 驗證遠端倉庫
git remote -v
```

### 步驟 4：推送到 GitHub

```bash
# 重命名分支為 main（GitHub 預設分支）
git branch -M main

# 推送所有提交
git push -u origin main
```

### 步驟 5：啟用 GitHub Pages

1. 進入您的倉庫頁面
2. 點擊「Settings」標籤
3. 在左側菜單找到「Pages」
4. 在「Source」下選擇：
   - **Branch**：`main`
   - **Folder**：`/ (root)`
5. 點擊「Save」

### 步驟 6：獲取線上連結

等待 1-2 分鐘，GitHub Pages 會自動部署。

您的網站將在以下地址可用：
```
https://YOUR_USERNAME.github.io/game-awards-showcase/
```

---

## ✅ 驗證部署

### 檢查部署狀態

1. 進入倉庫的「Settings」→「Pages」
2. 查看部署狀態（應顯示「Your site is live at...」）
3. 點擊提供的連結訪問網站

### 測試網站功能

- [ ] 首頁正常加載
- [ ] 搜尋功能正常
- [ ] 篩選按鈕正常
- [ ] 購買按鈕可點擊
- [ ] 活動按鈕可點擊
- [ ] 所有連結正常
- [ ] 響應式設計正常
- [ ] 無障礙功能正常

---

## 🔄 更新網站

如果您需要更新網站內容：

```bash
# 1. 修改檔案
# 編輯 index.html 或其他檔案

# 2. 提交變更
git add .
git commit -m "Update: 描述您的更改"

# 3. 推送到 GitHub
git push origin main
```

GitHub Pages 會自動重新部署（通常需要 1-2 分鐘）。

---

## 🆘 常見問題

### Q: 網站無法訪問？
**A**: 
1. 檢查倉庫是否為公開
2. 檢查 Pages 是否已啟用
3. 等待 1-2 分鐘讓 GitHub 完成部署
4. 清除瀏覽器快取並重新加載

### Q: 更新後網站沒有變化？
**A**:
1. 檢查提交是否成功（`git log`）
2. 檢查推送是否成功（`git push`）
3. 清除瀏覽器快取
4. 等待 1-2 分鐘讓 GitHub 重新部署

### Q: 如何自訂網域？
**A**:
1. 進入「Settings」→「Pages」
2. 在「Custom domain」欄位輸入您的網域
3. 按照 GitHub 的指示配置 DNS

### Q: 如何刪除倉庫？
**A**:
1. 進入倉庫「Settings」
2. 向下滾動到「Danger Zone」
3. 點擊「Delete this repository」
4. 按照提示確認

---

## 📚 有用的連結

- [GitHub Pages 官方文檔](https://docs.github.com/en/pages)
- [Git 官方文檔](https://git-scm.com/doc)
- [GitHub 快速入門](https://docs.github.com/en/get-started)

---

## 💡 提示

- 定期提交您的變更
- 使用有意義的提交訊息
- 保持倉庫的 README 更新
- 考慮添加 LICENSE 檔案

---

**祝您部署順利！** 🎉
