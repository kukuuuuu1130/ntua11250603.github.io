# The Game Awards 遊戲展示網站

## 📋 專案說明

這是一個根據 Figma 設計稿開發的遊戲展示網站，展示 TGA 年度遊戲和 Steam 活動。

**課程**：多媒體網頁設計  
**學號**：11250603  
**姓名**：鄭依晴  
**期中作業**：Figma to Web 網頁設計

---

## ✨ 網站特色

### 1. 設計實現
- ✅ 完全按照 Figma 設計稿製作
- ✅ 深色主題配色（灰色背景 + 黃色強調色）
- ✅ 遊戲卡片網格佈局
- ✅ Steam 活動橫幅區域
- ✅ 專業導航欄和頁腳

### 2. WCAG 無障礙標準
- ✅ 語義化 HTML 結構
- ✅ 完整的 ARIA 標籤
- ✅ 鍵盤導航支持
- ✅ 焦點可見性
- ✅ 高對比度模式
- ✅ 減少動畫模式

### 3. 互動功能
- ✅ 即時搜尋功能
- ✅ 遊戲類別篩選
- ✅ 購買按鈕
- ✅ 活動按鈕

### 4. 響應式設計
- ✅ 桌面版（1400px+）
- ✅ 平板版（768px - 1400px）
- ✅ 手機版（480px - 768px）
- ✅ 超小螢幕（< 480px）

---

## 📁 檔案結構

```
game-awards-showcase/
├── index.html          # 主頁面（單一檔案設計）
├── README.md           # 專案說明
├── assets/
│   └── images/         # 圖片資源（如需要）
└── .gitignore          # Git 忽略檔案
```

---

## 🚀 如何使用

### 本地查看
1. 下載或克隆此倉庫
2. 用瀏覽器直接打開 `index.html` 檔案
3. 或使用本地伺服器：
   ```bash
   python -m http.server 8000
   # 或
   npx http-server
   ```

### 線上查看
訪問 GitHub Pages 連結：
- [https://github-username.github.io/game-awards-showcase/](https://github-username.github.io/game-awards-showcase/)

---

## 🎨 設計細節

### 色彩方案
- **主背景**：#4a4a4a（灰色）
- **次背景**：#3a3a3a（深灰色）
- **強調色**：#ffed00（黃色）
- **文字**：#ffffff（白色）

### 字體
- 系統預設字體堆棧（跨平台相容性最佳）

### 響應式斷點
- 桌面：1400px+
- 平板：768px - 1400px
- 手機：480px - 768px
- 超小：< 480px

---

## ♿ 無障礙特性

### WCAG 2.1 AA 標準
- ✅ 語義化標記
- ✅ ARIA 標籤和角色
- ✅ 鍵盤可訪問性
- ✅ 焦點管理
- ✅ 顏色對比度
- ✅ 文本替代

### 支持的輔助技術
- 螢幕閱讀器（NVDA、JAWS、VoiceOver）
- 鍵盤導航
- 高對比度模式
- 減少動畫模式

---

## 📊 技術棧

- **HTML5**：語義化標記
- **CSS3**：響應式設計、Flexbox、Grid
- **JavaScript**：搜尋、篩選、互動功能
- **無障礙**：WCAG 2.1 AA 標準

---

## 📝 開發筆記

### 關鍵實現
1. **單一 HTML 檔案**：所有 CSS 和 JavaScript 內嵌，便於部署
2. **響應式網格**：使用 CSS Grid 實現自適應卡片佈局
3. **搜尋功能**：JavaScript 即時篩選遊戲卡片
4. **無障礙優先**：從設計階段就考慮無障礙需求

### 優化建議
- 如需要圖片，建議使用 jpg 格式（檔案較小）
- 保持檔案大小 < 5MB
- 使用英文檔案名稱或 dash 分隔符

---

## 🔗 相關連結

- [Figma 設計稿](https://www.figma.com/design/OVzMdz7wz7eClUS5FKSGhS/)
- [WCAG 2.1 標準](https://www.w3.org/WAI/WCAG21/quickref/)
- [MDN Web Docs](https://developer.mozilla.org/)

---

## 📧 聯絡方式

- **學號**：11250603
- **姓名**：鄭依晴
- **Email**：mark171@gmail.com

---

## 📅 重要日期

- **作業截止**：2026/1/1
- **課堂展示**：2026/1/2

---

## 📄 授權

此專案為課程作業，僅供教育用途。

---

**最後更新**：2026 年 1 月 1 日
