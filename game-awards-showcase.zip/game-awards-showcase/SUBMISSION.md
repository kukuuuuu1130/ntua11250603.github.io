# 課程作業提交說明

## 📚 課程資訊

- **課程名稱**：多媒體網頁設計
- **課程代碼**：114-1
- **作業類型**：Figma to Web 網頁設計
- **學號**：11250603
- **姓名**：鄭依晴
- **Email**：mark171@gmail.com

---

## 📝 作業要求清單

### ✅ 必須完成項目

- [x] 利用 Figma 版型，利用 HTML + CSS 製作成網頁
- [x] 請將完成作品上傳到 GitHub 網頁空間，並將超連結貼上至 Teams 會議提出
- [x] 過程中若有問題請見「Figma to Web 設計示範(預覽片)」
- [x] 遵守 WCAG 無障礙規則

### ✅ 檔案狀態

- [x] 網站首頁：`index.html`
- [x] 因為網站主機會預設找 index 的檔案
- [x] 如果因故無法出現請提出原因

### ✅ 檔案與資料夾名稱

- [x] 使用英文、中文皆可以但不易過長
- [x] 避免使用特殊符號（例如：`name0110`）
- [x] 使用 dash（`-`）分隔，避免使用底線（`_`）
- [x] 檔案大小：因為網頁傳輸會限制大小，建議小於 5MB

### ✅ 圖片與多媒體

- [x] 建議使用 jpg 格式（因為 png 檔案較大）
- [x] 如有其他類型圖片，會選擇 jpg 格式最佳
- [x] 使用 png 是最優化存放方式（用於預覽截圖）

### ✅ Figma 設計稿

- [x] 使用 Photoshop 或 Figma 輸出合適的圖檔尺寸
- [x] 小圖建議縮放式（像圖中所示的預覽方式）
- [x] 附帶截圖用於課堂展示

---

## 🎯 完成品展示 (2026/1/2)

### 網站連結
- **GitHub 倉庫**：[game-awards-showcase](https://github.com/your-username/game-awards-showcase)
- **線上預覽**：[GitHub Pages 連結](https://your-username.github.io/game-awards-showcase/)

### 展示內容
1. ✅ 完整的網站首頁
2. ✅ 遊戲卡片網格佈局
3. ✅ Steam 活動區域
4. ✅ 響應式設計演示
5. ✅ 無障礙功能展示

---

## 📊 技術實現

### HTML 結構
- 語義化標記（`<header>`, `<main>`, `<footer>`, `<article>`, `<section>`）
- ARIA 標籤和角色
- 完整的表單標籤

### CSS 樣式
- 響應式設計（Mobile First）
- CSS Grid 和 Flexbox 佈局
- CSS 變數管理色彩
- 媒體查詢支持

### JavaScript 功能
- 搜尋功能
- 篩選功能
- 按鈕互動
- 鍵盤導航

### 無障礙特性
- WCAG 2.1 AA 標準
- 焦點管理
- 顏色對比度
- 文本替代
- 減少動畫支持

---

## 📁 檔案結構

```
game-awards-showcase/
├── index.html              # 主頁面
├── README.md               # 專案說明
├── SUBMISSION.md           # 作業提交說明（本檔案）
├── .gitignore              # Git 忽略檔案
└── assets/
    └── images/
        ├── preview-1.png   # 首頁截圖
        ├── preview-2.png   # 活動區截圖
        └── preview-3.png   # 頁腳截圖
```

---

## 🔍 品質檢查清單

### 功能測試
- [x] 搜尋功能正常運作
- [x] 篩選按鈕正常運作
- [x] 購買按鈕可點擊
- [x] 所有連結可訪問

### 設計檢查
- [x] 色彩方案符合設計稿
- [x] 排版和間距一致
- [x] 字體大小合適
- [x] 圖片清晰

### 響應式檢查
- [x] 桌面版（1400px+）
- [x] 平板版（768px - 1400px）
- [x] 手機版（480px - 768px）
- [x] 超小螢幕（< 480px）

### 無障礙檢查
- [x] 鍵盤導航完整
- [x] 焦點可見性清晰
- [x] 顏色對比度達標
- [x] ARIA 標籤正確
- [x] 螢幕閱讀器相容

### 效能檢查
- [x] 檔案大小 < 5MB
- [x] 載入速度快
- [x] 沒有控制台錯誤
- [x] 沒有警告

---

## 📸 預覽截圖

### 首頁截圖
![首頁預覽](./game-awards-showcase-preview.png)

### 活動區截圖
![活動區預覽](./game-awards-events-section.png)

### 頁腳截圖
![頁腳預覽](./game-awards-footer.png)

---

## 🎓 學習重點

### 在這個專案中學到的技能

1. **Figma 設計轉換**
   - 理解設計稿的結構
   - 提取色彩和排版信息
   - 實現設計細節

2. **HTML 語義化**
   - 使用正確的標籤
   - 改善 SEO
   - 提高可訪問性

3. **CSS 響應式設計**
   - 媒體查詢應用
   - Flexbox 和 Grid
   - 移動優先設計

4. **JavaScript 互動**
   - DOM 操作
   - 事件監聽
   - 動態篩選

5. **無障礙設計**
   - WCAG 標準
   - ARIA 屬性
   - 鍵盤導航

---

## 🚀 部署步驟

### 1. 上傳到 GitHub

```bash
# 初始化 Git 倉庫
git init

# 添加所有檔案
git add .

# 提交變更
git commit -m "Initial commit: Figma to Web 遊戲展示網站"

# 添加遠端倉庫
git remote add origin https://github.com/your-username/game-awards-showcase.git

# 推送到 GitHub
git push -u origin master
```

### 2. 啟用 GitHub Pages

1. 進入倉庫設定
2. 找到 "Pages" 部分
3. 選擇 "Deploy from a branch"
4. 選擇 "master" 分支
5. 保存設定

### 3. 獲取線上連結

- GitHub Pages URL：`https://your-username.github.io/game-awards-showcase/`

---

## 📞 聯絡資訊

如有任何問題，請通過以下方式聯絡：

- **Email**：mark171@gmail.com
- **Teams**：課程 Teams 頻道
- **GitHub Issues**：[提出 Issue](https://github.com/your-username/game-awards-showcase/issues)

---

## 📅 重要日期

- **作業截止**：2026 年 1 月 1 日
- **課堂展示**：2026 年 1 月 2 日

---

## ✨ 特別感謝

感謝課程講師的指導和同學的支持！

---

**提交日期**：2026 年 1 月 1 日  
**最後更新**：2026 年 1 月 1 日
